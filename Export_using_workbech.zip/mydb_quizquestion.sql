-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quizquestion`
--

DROP TABLE IF EXISTS `quizquestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quizquestion` (
  `quizquestion_id` int NOT NULL AUTO_INCREMENT,
  `quiz_id` int NOT NULL,
  `question_id` int NOT NULL,
  `choice_id` int NOT NULL,
  `order_num` int DEFAULT NULL,
  PRIMARY KEY (`quizquestion_id`),
  KEY `fk_quizquestion_quiz1_idx` (`quiz_id`),
  KEY `fk_quizquestion_question1_idx` (`question_id`),
  KEY `fk_quizquestion_choice1_idx` (`choice_id`),
  CONSTRAINT `fk_quizquestion_choice1` FOREIGN KEY (`choice_id`) REFERENCES `choice` (`choice_id`),
  CONSTRAINT `fk_quizquestion_question1` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_id`),
  CONSTRAINT `fk_quizquestion_quiz1` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`quiz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quizquestion`
--

LOCK TABLES `quizquestion` WRITE;
/*!40000 ALTER TABLE `quizquestion` DISABLE KEYS */;
INSERT INTO `quizquestion` VALUES (1,5,14,42,0),(2,5,11,31,0),(3,5,15,44,0),(4,5,12,35,0),(5,5,13,38,0),(6,7,3,8,0),(7,7,4,11,0),(8,7,2,6,0),(9,7,5,15,0),(10,7,1,2,0),(11,12,4,10,0),(12,12,1,2,0),(13,12,5,14,0),(14,12,3,7,0),(15,12,2,6,0),(16,13,14,41,0),(17,13,11,32,0),(18,13,12,35,0),(19,13,15,43,0),(20,13,13,39,0),(25,27,5,13,0),(26,28,7,19,0),(27,28,9,25,0),(28,28,10,28,0),(29,28,8,22,0),(30,28,6,17,0),(31,29,7,19,0),(32,29,10,29,0),(33,29,9,26,0),(34,29,6,17,0),(35,29,8,23,0),(36,34,1,2,0),(37,34,3,8,0),(38,34,5,14,0),(39,34,2,6,0),(40,34,4,11,0),(41,35,5,13,0),(42,35,2,4,0),(43,35,4,11,0),(44,35,3,7,0),(45,35,1,2,0),(46,36,7,20,0),(47,36,8,23,0),(48,36,10,28,0),(49,36,9,27,0),(50,36,6,16,0),(51,37,1,2,0),(52,37,5,14,0),(53,37,4,11,0),(54,37,3,8,0),(55,37,2,4,0),(56,38,3,7,0),(57,38,1,2,0),(58,38,2,6,0),(59,38,5,14,0),(60,38,4,10,0),(61,39,2,6,0),(62,39,1,2,0),(63,39,4,10,0),(64,39,5,13,0),(65,39,3,8,0),(66,40,10,28,0),(67,40,7,20,0),(68,40,8,23,0),(69,40,9,27,0),(70,40,6,16,0),(71,41,3,7,0),(72,41,4,10,0),(73,41,2,6,0),(74,41,1,2,0),(75,41,5,14,0),(76,42,1,2,0),(77,42,3,7,0),(78,42,5,14,0),(79,42,16,47,0),(80,42,17,50,0),(81,43,9,27,0),(82,43,10,28,0),(83,43,7,20,0),(84,43,8,23,0),(85,43,6,16,0),(86,44,12,35,0),(87,44,14,41,0),(88,44,15,44,0),(89,44,13,38,0),(90,44,11,32,0),(91,45,1,1,0),(92,45,5,14,0),(93,45,4,10,0),(94,45,2,6,0),(95,45,16,47,0),(96,46,8,22,0),(97,46,10,29,0),(98,46,7,19,0),(99,46,9,25,0),(100,46,6,17,0),(101,47,17,50,0),(102,47,16,47,0),(103,47,2,6,0),(104,47,4,10,0),(105,47,3,7,0),(106,48,5,13,0),(107,48,2,6,0),(108,48,4,10,0),(109,48,17,50,0),(110,48,16,47,0),(111,49,8,23,0),(112,49,7,20,0),(113,49,9,27,0),(114,49,10,28,0),(115,49,18,53,0),(116,50,12,34,0),(117,50,14,41,0),(118,50,11,32,0),(119,50,15,44,0),(120,50,13,38,0);
/*!40000 ALTER TABLE `quizquestion` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-21 10:01:08
