-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quiz`
--

DROP TABLE IF EXISTS `quiz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz` (
  `quiz_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `category_id` int NOT NULL,
  `quiz_name` varchar(45) DEFAULT NULL,
  `quiz_time_start` timestamp NULL DEFAULT NULL,
  `quiz_time_end` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`quiz_id`),
  KEY `fk_quiz_user_idx` (`user_id`),
  KEY `fk_quiz_category1_idx` (`category_id`),
  CONSTRAINT `fk_quiz_category1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`),
  CONSTRAINT `fk_quiz_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz`
--

LOCK TABLES `quiz` WRITE;
/*!40000 ALTER TABLE `quiz` DISABLE KEYS */;
INSERT INTO `quiz` VALUES (1,4,1,'ann.benPlus','2022-09-18 14:57:27',NULL),(2,4,1,'ann.benPlus','2022-09-18 14:57:27','2022-09-18 14:57:38'),(3,4,2,'ann.benMinus','2022-09-18 15:00:43',NULL),(4,4,2,'ann.benMinus','2022-09-18 15:00:43','2022-09-18 15:01:20'),(5,4,3,'ann.benMuti','2022-09-18 15:09:22',NULL),(6,4,3,'ann.benMuti','2022-09-18 15:09:22','2022-09-18 15:09:31'),(7,4,1,'ann.benPlus','2022-09-18 15:27:41','2022-09-18 15:27:54'),(8,1,1,'scott.TangPlus','2022-09-18 15:49:03',NULL),(9,1,2,'scott.TangMinus','2022-09-18 15:49:08',NULL),(10,1,3,'scott.TangMuti','2022-09-18 15:49:14',NULL),(11,4,1,'ann.benPlus','2022-09-18 15:49:25',NULL),(12,4,1,'ann.benPlus','2022-09-18 16:41:30','2022-09-18 16:41:42'),(13,4,3,'ann.benMuti','2022-09-18 19:22:22','2022-09-18 19:22:40'),(16,4,1,'ann.benPlus','2022-09-19 00:14:01',NULL),(17,4,1,'ann.benPlus','2022-09-19 00:18:41',NULL),(18,4,1,'ann.benPlus','2022-09-19 00:20:47',NULL),(19,4,1,'ann.benPlus','2022-09-19 00:22:12',NULL),(20,4,1,'ann.benPlus','2022-09-19 00:22:58',NULL),(21,4,1,'ann.benPlus','2022-09-19 00:24:08',NULL),(22,4,1,'ann.benPlus','2022-09-19 00:38:01',NULL),(23,4,1,'ann.benPlus','2022-09-19 00:42:23',NULL),(24,4,1,'ann.benPlus','2022-09-19 00:49:00',NULL),(25,4,1,'ann.benPlus','2022-09-19 00:52:01',NULL),(26,4,1,'ann.benPlus','2022-09-19 00:53:05',NULL),(27,4,1,'ann.benPlus','2022-09-19 00:54:18','2022-09-19 00:54:55'),(28,4,2,'ann.benMinus','2022-09-19 00:55:48','2022-09-19 00:55:58'),(29,4,2,'ann.benMinus','2022-09-19 00:56:03','2022-09-19 00:56:24'),(30,4,1,'ann.benPlus','2022-09-19 00:56:41',NULL),(31,4,1,'ann.benPlus','2022-09-19 01:06:06',NULL),(32,4,1,'ann.benPlus','2022-09-19 03:03:51',NULL),(33,4,1,'ann.benPlus','2022-09-19 03:05:16',NULL),(34,4,1,'ann.benPlus','2022-09-19 15:23:54','2022-09-19 15:24:18'),(35,4,1,'ann.benPlus','2022-09-19 15:28:38','2022-09-19 15:29:04'),(36,10,2,'t.aMinus','2022-09-19 15:31:25','2022-09-19 15:31:37'),(37,12,1,'t.f-Plus','2022-09-20 04:23:43','2022-09-20 04:23:51'),(38,4,1,'ann.ben-Plus','2022-09-20 23:24:08','2022-09-20 23:24:29'),(39,13,1,'Test.A-Plus','2022-09-20 23:28:21','2022-09-20 23:28:36'),(40,13,2,'Test.A-Minus','2022-09-20 23:28:52','2022-09-20 23:29:02'),(41,4,1,'ann.ben-Plus','2022-09-21 00:24:16','2022-09-21 00:24:30'),(42,14,1,'a.a-Plus','2022-09-21 05:49:38','2022-09-21 05:50:04'),(43,14,2,'a.a-Minus','2022-09-21 05:50:25','2022-09-21 05:50:41'),(44,14,3,'a.a-Muti','2022-09-21 05:50:50','2022-09-21 05:50:59'),(45,4,1,'ann.ben-Plus','2022-09-21 07:03:44','2022-09-21 07:03:53'),(46,4,2,'ann.ben-Minus','2022-09-21 07:04:23','2022-09-21 07:04:34'),(47,22,1,'at.ax-Plus','2022-09-21 12:30:54','2022-09-21 12:31:13'),(48,23,1,'a.a-Plus','2022-09-21 14:35:26','2022-09-21 14:35:49'),(49,23,2,'a.a-Minus','2022-09-21 14:36:17','2022-09-21 14:36:28'),(50,23,3,'a.a-Muti','2022-09-21 14:36:38','2022-09-21 14:36:54');
/*!40000 ALTER TABLE `quiz` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-21 10:01:08
